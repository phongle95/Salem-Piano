(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trang-chu-trang-chu-module"],{

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html":
/*!*****************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n  <div class=\"row\">\n    <div class=\"col\">\n\n      <!-- Section: Testimonials v.2 -->\n      <section class=\"text-center my-5\">\n\n        <h2 class=\"h3-responsive text-center text-uppercase font-weight-bold my-5 \">đánh giá\n          khách hàng\n        </h2>\n        <!-- Carousel Wrapper -->\n        <div id=\"carousel-example-1\" class=\"carousel no-flex testimonial-carousel slide\" data-ride=\"carousel\">\n          <!--Slides-->\n          <div class=\"carousel-inner\" role=\"listbox\">\n            <!--First slide-->\n            <div class=\"carousel-item active\">\n              <div class=\"testimonial\">\n                <!--Avatar-->\n                <div class=\"avatar mx-auto mb-4\">\n                  <img src=\"../../../../assets/img/girl.jpg\" class=\"rounded-circle img-fluid\" alt=\"First sample avatar image\">\n                </div>\n\n                <!--Content-->\n                <p class=\"font-weight-normal\">\n                  \"Tư vấn rất nhiệt tình và đàn rất chất lượng. Tôi cho 5 sao. Sẽ ủng hộ tiếp .I really love their\n                  services, the piano i just bought here is excellent !!!\"\n                </p>\n                <div class=\"color\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h5 class=\"font-weight-bold mt-4 mb-3\">Thanh Ngân</h5>\n                <ul class=\"list-unstyled mb-0\">\n                  <!-- Facebook -->\n                  <a class=\"p-2 fa-lg fb-ic\">\n                    <i class=\"fa fa-facebook blue-text\"> </i>\n                  </a>\n                  <!-- Twitter -->\n                  <a class=\"p-2 fa-lg tw-ic\">\n                    <i class=\"fa fa-twitter blue-text\"> </i>\n                  </a>\n                  <!-- Instagram -->\n                  <a class=\"p-2 fa-lg ins-ic\">\n                    <i class=\"fa fa-instagram blue-text\"> </i>\n                  </a>\n                </ul>\n\n                <!--Review-->\n\n              </div>\n            </div>\n            <!--First slide-->\n            <!--Second slide-->\n            <div class=\"carousel-item\">\n              <div class=\"testimonial\">\n                <!--Avatar-->\n                <div class=\"avatar mx-auto mb-4\">\n                  <img src=\"../../../../assets/img/girl1.jpg\" class=\"rounded-circle img-fluid\" alt=\"Second sample avatar image\">\n                </div>\n                <p class=\"font-weight-normal\">\n                  \"Nơi đây đàn đẹp, mẫu mã đa dạng, chất lượng tốt mà giá lại rẻ. Chất lượng dịch vụ tốt.Em rất thích\n                  sản phẩm ở đây cho shop 5 sao i love you Salem Piano\"\n                </p>\n                <div class=\"color\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h5 class=\"font-weight-bold mt-4 mb-3\">Mỹ Linh</h5>\n                <ul class=\"list-unstyled mb-0\">\n                  <!-- Facebook -->\n                  <a class=\"p-2 fa-lg fb-ic\">\n                    <i class=\"fa fa-facebook blue-text\"> </i>\n                  </a>\n                  <!-- Twitter -->\n                  <a class=\"p-2 fa-lg tw-ic\">\n                    <i class=\"fa fa-twitter blue-text\"> </i>\n                  </a>\n                  <!-- Instagram -->\n                  <a class=\"p-2 fa-lg ins-ic\">\n                    <i class=\"fa fa-instagram blue-text\"> </i>\n                  </a>\n                </ul>\n              </div>\n            </div>\n            <!--Second slide-->\n\n            <div class=\"carousel-item\">\n              <div class=\"testimonial\">\n                <!--Avatar-->\n                <div class=\"avatar mx-auto mb-4\">\n                  <img src=\"../../../../assets/img/girl3.jpg\" class=\"rounded-circle img-fluid\" alt=\"Second sample avatar image\">\n                </div>\n                <p class=\"font-weight-normal\">\n                  \"Nơi đây đàn đẹp, mẫu mã đa dạng, chất lượng tốt mà giá lại rẻ. Chất lượng dịch vụ tốt.I really love\n                  their\n                  services, the piano i just bought here is excellent !!!\"\n                </p>\n                <div class=\"color\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h5 class=\"font-weight-bold mt-4 mb-3\">Ngọc Hiền</h5>\n                <ul class=\"list-unstyled mb-0\">\n                  <!-- Facebook -->\n                  <a class=\"p-2 fa-lg fb-ic\">\n                    <i class=\"fa fa-facebook blue-text\"> </i>\n                  </a>\n                  <!-- Twitter -->\n                  <a class=\"p-2 fa-lg tw-ic\">\n                    <i class=\"fa fa-twitter blue-text\"> </i>\n                  </a>\n                  <!-- Instagram -->\n                  <a class=\"p-2 fa-lg ins-ic\">\n                    <i class=\"fa fa-instagram blue-text\"> </i>\n                  </a>\n                </ul>\n              </div>\n            </div>\n            <!--Second slide-->\n\n          </div>\n          <!--Slides-->\n          <!--Controls-->\n          <a class=\"carousel-item-prev left carousel-control\" href=\"#carousel-example-1\" role=\"button\" data-slide=\"prev\">\n            <span class=\"icon-prev\" aria-hidden=\"true\"></span>\n            <span class=\"sr-only\">Previous</span>\n          </a>\n          <a class=\"carousel-item-next right carousel-control\" href=\"#carousel-example-1\" role=\"button\" data-slide=\"next\">\n            <span class=\"icon-next\" aria-hidden=\"true\"></span>\n            <span class=\"sr-only\">Next</span>\n          </a>\n          <!--Controls-->\n        </div>\n        <!-- Carousel Wrapper -->\n\n      </section>\n      <!-- Section: Testimonials v.2 -->\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".color {\n  color: #ffca28; }\n\n@media (max-width: 1199.98px) {\n  .line {\n    width: 100%;\n    height: 10px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvZGFuaC1naWEta2hhY2gvQzpcXHhhbXBwXFxodGRvY3NcXGFwcF9waWFuby9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxkYW5oLWdpYS1raGFjaFxcZGFuaC1naWEta2hhY2guY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFlLEVBQ2pCOztBQUlEO0VBQ0c7SUFDSSxZQUFZO0lBQ1osYUFBWSxFQUNmLEVBQUEiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS9kYW5oLWdpYS1raGFjaC9kYW5oLWdpYS1raGFjaC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb2xvcntcclxuICAgIGNvbG9yOiAgI2ZmY2EyODtcclxuIH1cclxuXHJcblxyXG5cclxuIEBtZWRpYSAobWF4LXdpZHRoOiAxMTk5Ljk4cHgpIHtcclxuICAgIC5saW5le1xyXG4gICAgICAgIHdpZHRoOiAxMDAlIDtcclxuICAgICAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICB9XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts ***!
  \***************************************************************************/
/*! exports provided: DanhGiaKhachComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DanhGiaKhachComponent", function() { return DanhGiaKhachComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DanhGiaKhachComponent = /** @class */ (function () {
    function DanhGiaKhachComponent() {
    }
    DanhGiaKhachComponent.prototype.ngOnInit = function () {
    };
    DanhGiaKhachComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-danh-gia-khach',
            template: __webpack_require__(/*! ./danh-gia-khach.component.html */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html"),
            styles: [__webpack_require__(/*! ./danh-gia-khach.component.scss */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], DanhGiaKhachComponent);
    return DanhGiaKhachComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<hr>\n<!-- <h3 class=\"text-center text-default\" style=\"font-weight: 500\">SẢN PHẨM BÁN CHẠY</h3> -->\n<h4 class=\"text-center text-primary h3-responsive font-weight-bold my-5\">SẢN PHẨM BÁN CHẠY</h4>\n<br>\n\n<mdb-carousel [isControls]=\"true\" [interval]=\"2000\" class=\"carousel-multi-item multi-animation\" [type]=\"'carousel-multi-item'\"\n    [animation]=\"'slide'\">\n    <mdb-carousel-item *ngFor=\"let item of slides; let i = index\">\n        <div class=\"col-md-4\" *ngFor=\"let data of item\">\n            <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{data.id}}\">\n                <mdb-card class=\"my-1\">\n                    <mdb-card-img class=\"view overlay img custom-image img-fluid\" [src]=\"data.hinhAnh\" alt=\"Card image cap\">\n                    </mdb-card-img>\n                    <mdb-card-body>\n                        <hr>\n                        <mdb-card-title>\n                            <a title=\"piano\" routerLink=\"#\">\n                                <h4 class=\"custom-title\">{{data.tenSP}}</h4>\n                            </a>\n                        </mdb-card-title>\n                        <div class=\"yellow-text text-center\">\n                            <i class=\"fa fa-star\"> </i>\n                            <i class=\"fa fa-star\"> </i>\n                            <i class=\"fa fa-star\"> </i>\n                            <i class=\"fa fa-star\"> </i>\n                            <i class=\"fa fa-star\"> </i>\n                          </div>\n                        <h6 class=\"custom-price\">Giá: {{data.gia}} vnđ</h6>\n                        <h6 class=\"custom-description\"></h6>\n                    </mdb-card-body>\n                </mdb-card>\n            </a>\n        </div>\n    </mdb-carousel-item>\n</mdb-carousel>"

/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".custom-image {\n  height: 300px; }\n\n.custom-title {\n  text-align: center;\n  font-weight: 500;\n  color: #000;\n  font-size: 110%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-price {\n  text-align: center;\n  font-weight: 500;\n  color: #ff4444;\n  font-size: 90%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-description {\n  text-align: center;\n  font-weight: 300;\n  color: #37474F;\n  font-size: 80%;\n  font-family: \"Helvetica\", Times, serif; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2FuLXBoYW0tYmFuLWNoYXkvQzpcXHhhbXBwXFxodGRvY3NcXGFwcF9waWFuby9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxzYW4tcGhhbS1iYW4tY2hheVxcc2FuLXBoYW0tYmFuLWNoYXkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFhLEVBQ2hCOztBQUVEO0VBQ0csbUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixZQUFZO0VBQ1osZ0JBQWU7RUFDZix1Q0FBc0M7RUFDdEMsMEJBQXlCLEVBQzNCOztBQUVEO0VBQ0csbUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBYztFQUNkLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDM0I7O0FBRUQ7RUFDRyxtQkFBa0I7RUFDbEIsaUJBQWdCO0VBQ2hCLGVBQWU7RUFDZixlQUFjO0VBQ2QsdUNBQXNDLEVBQ3hDIiwiZmlsZSI6InNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2FuLXBoYW0tYmFuLWNoYXkvc2FuLXBoYW0tYmFuLWNoYXkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLWltYWdleyBcclxuICAgIGhlaWdodDogMzAwcHg7XHJcbn0gXHJcblxyXG4uY3VzdG9tLXRpdGxle1xyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgIGNvbG9yOiAjMDAwIDsgXHJcbiAgIGZvbnQtc2l6ZTogMTEwJTtcclxuICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufSBcclxuXHJcbi5jdXN0b20tcHJpY2V7XHJcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgY29sb3I6ICNmZjQ0NDQgOyBcclxuICAgZm9udC1zaXplOiA5MCU7XHJcbiAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn0gXHJcblxyXG4uY3VzdG9tLWRlc2NyaXB0aW9ue1xyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgIGNvbG9yOiAjMzc0NzRGIDsgXHJcbiAgIGZvbnQtc2l6ZTogODAlO1xyXG4gICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG59XHJcblxyXG5cclxuLy8gLmltZ3tcclxuLy8gICAgIHdpZHRoOiA1MDBweDtcclxuLy8gICAgIGhlaWdodDogNDAwcHg7XHJcbi8vICAgICBwYWRkaW5nLWxlZnQ6IDc3cHg7XHJcbi8vIH0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.ts ***!
  \*********************************************************************************/
/*! exports provided: SanPhamBanChayComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SanPhamBanChayComponent", function() { return SanPhamBanChayComponent; });
/* harmony import */ var src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/api/piano.service */ "./src/app/api/piano.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SanPhamBanChayComponent = /** @class */ (function () {
    function SanPhamBanChayComponent(pianoService) {
        this.pianoService = pianoService;
        this.slides = [[]];
    }
    SanPhamBanChayComponent.prototype.ngOnInit = function () {
        this.getPiano();
    };
    //getPiano
    SanPhamBanChayComponent.prototype.getPiano = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '26')
            .subscribe(function (data) {
            _this.listPiano = data;
            _this.slides = _this.chunk(_this.listPiano, 3);
        });
    };
    SanPhamBanChayComponent.prototype.chunk = function (arr, chunkSize) {
        var R = [];
        for (var i = 0, len = arr.length; i < len; i += chunkSize) {
            R.push(arr.slice(i, i + chunkSize));
        }
        return R;
    };
    SanPhamBanChayComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-san-pham-ban-chay',
            template: __webpack_require__(/*! ./san-pham-ban-chay.component.html */ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.html"),
            styles: [__webpack_require__(/*! ./san-pham-ban-chay.component.scss */ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__["PianoService"]])
    ], SanPhamBanChayComponent);
    return SanPhamBanChayComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<br><br>\n<h3 class=\"text-center black-text\" style=\"font-weight: 500\">SẢN PHẨM NỖI BẬT</h3>\n<br>\n<!-- \n<mdb-carousel [isControls]=\"true\" [interval]=\"2000\" class=\"carousel-multi-item multi-animation\" [type]=\"'carousel-multi-item'\"\n  [animation]=\"'slide'\">\n  <mdb-carousel-item *ngFor=\"let item of slides; let i = index\">\n    <div class=\"col-md-4\" *ngFor=\"let data of item\">\n      <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{data.id}}\">\n        <mdb-card class=\"my-1\">\n          <mdb-card-img class=\"view overlay img custom-image img-fluid\" [src]=\"data.hinhAnh\" alt=\"Card image cap\">\n          </mdb-card-img>\n          <mdb-card-body>\n            <hr>\n            <mdb-card-title>\n              <a title=\"piano\" routerLink=\"#\">\n                <h4 class=\"custom-title\">{{data.tenSP}}</h4>\n              </a>\n            </mdb-card-title>\n            <div class=\"yellow-text text-center\">\n              <i class=\"fa fa-star\"> </i>\n              <i class=\"fa fa-star\"> </i>\n              <i class=\"fa fa-star\"> </i>\n              <i class=\"fa fa-star\"> </i>\n              <i class=\"fa fa-star\"> </i>\n            </div>\n            <h6 class=\"custom-price\">Giá: {{data.gia}} vnđ</h6>\n            <h6 class=\"custom-description\"></h6>\n          </mdb-card-body>\n        </mdb-card>\n      </a>\n    </div>\n  </mdb-carousel-item>\n</mdb-carousel> -->\n\n\n<!--Carousel Wrapper-->\n<div id=\"multi-item-example\" class=\"carousel slide carousel-multi-item\" data-ride=\"carousel\">\n\n  <!--Controls-->\n  <div class=\"controls-top\">\n    <a class=\"btn-floating\" href=\"#multi-item-example\" data-slide=\"prev\">\n      <i class=\"fa fa-caret-left fa-2x white-text\"></i>\n    </a>\n    <a class=\"btn-floating\" href=\"#multi-item-example\" data-slide=\"next\">\n      <i class=\"fa fa-caret-right fa-2x white-text\"></i>\n    </a>\n  </div>\n  <!--/.Controls-->\n\n  <!--Indicators-->\n  <ol class=\"carousel-indicators\">\n    <li data-target=\"#multi-item-example\" data-slide-to=\"0\" class=\"active\"></li>\n    <li data-target=\"#multi-item-example\" data-slide-to=\"1\"></li>\n    <li data-target=\"#multi-item-example\" data-slide-to=\"3\"></li>\n  </ol>\n  <!--/.Indicators-->\n\n  <!--Slides-->\n  <div class=\"carousel-inner\" role=\"listbox\">\n\n    <!--First slide-->\n    <div class=\"carousel-item active\">\n\n      <div class=\"col-md-4\" *ngFor=\"let piano of listPiano03\">\n        <div class=\"card my-1\">\n          <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n            <img class=\"card-img-top img-fluid custom-image\" src=\"{{piano.hinhAnh}}\" alt=\"{{piano.tuKhoa}}\">\n          </a>\n          <div class=\"card-body custum-body\">\n            <div class=\"row\">\n\n              <div class=\"col\">\n                <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <p class=\"custom-title white-text\" style=\"font-size: 15px\">\n                    <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> {{piano.tenSP}}</p>\n                   \n                  <p class=\"custom-title yellow-text\" style=\"font-size: 12px\"> Giá: {{piano.gia}} vnđ</p>\n                </a>\n              </div>\n              <div class=\"col\">\n                <a class=\"btn btn-sm btn-yellow \" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <strong>Chi tiết</strong>\n                </a>\n\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-4 clearfix d-none d-md-block\" *ngFor=\"let piano of listPiano33\">\n        <div class=\"card my-1\">\n          <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n            <img class=\"card-img-top img-fluid custom-image\" src=\"{{piano.hinhAnh}}\" alt=\"{{piano.tuKhoa}}\">\n          </a>\n          <div class=\"card-body custum-body\">\n            <div class=\"row\">\n\n              <div class=\"col\">\n                <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <p class=\"custom-title white-text\" style=\"font-size: 15px\">\n                    <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> {{piano.tenSP}}</p>\n                  <p class=\"custom-title yellow-text\" style=\"font-size: 12px\"> Giá: {{piano.gia}} vnđ</p>\n                </a>\n              </div>\n              <div class=\"col\">\n                <a class=\"btn btn-sm btn-yellow \" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <strong>Chi tiết</strong>\n                </a>\n\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n\n\n    </div>\n    <!--/.First slide-->\n\n    <!--Second slide-->\n    <div class=\"carousel-item\">\n\n\n      <div class=\"col-md-4\" *ngFor=\"let piano of listPiano31\">\n        <div class=\"card my-1\">\n          <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n            <img class=\"card-img-top img-fluid custom-image\" src=\"{{piano.hinhAnh}}\" alt=\"{{piano.tuKhoa}}\">\n          </a>\n          <div class=\"card-body custum-body\">\n            <div class=\"row\">\n\n              <div class=\"col\">\n                <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <p class=\"custom-title white-text\" style=\"font-size: 15px\">\n                    <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> {{piano.tenSP}}</p>\n                  <p class=\"custom-title yellow-text\" style=\"font-size: 12px\"> Giá: {{piano.gia}} vnđ</p>\n                </a>\n              </div>\n              <div class=\"col\">\n                <a class=\"btn btn-sm btn-yellow \" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <strong>Chi tiết</strong>\n                </a>\n\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-4 clearfix d-none d-md-block\" *ngFor=\"let piano of listPiano42\">\n        <div class=\"card my-1\">\n          <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n            <img class=\"card-img-top img-fluid custom-image\" src=\"{{piano.hinhAnh}}\" alt=\"{{piano.tuKhoa}}\">\n          </a>\n          <div class=\"card-body custum-body\">\n            <div class=\"row\">\n\n              <div class=\"col\">\n                <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <p class=\"custom-title white-text\" style=\"font-size: 15px\">\n                    <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> {{piano.tenSP}}</p>\n                  <p class=\"custom-title yellow-text\" style=\"font-size: 12px\"> Giá: {{piano.gia}} vnđ</p>\n                </a>\n              </div>\n              <div class=\"col\">\n                <a class=\"btn btn-sm btn-yellow \" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                  <strong>Chi tiết</strong>\n                </a>\n\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n    </div>\n    <!--/.Second slide-->\n\n\n\n  </div>\n  <!--/.Slides-->\n\n</div>\n<!--/.Carousel Wrapper-->"

/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".custom-image {\n  height: 300px; }\n\n.custom-price {\n  text-align: center;\n  font-weight: 500;\n  color: #ff4444;\n  font-size: 90%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-description {\n  text-align: center;\n  font-weight: 300;\n  color: #37474F;\n  font-size: 80%;\n  font-family: \"Helvetica\", Times, serif; }\n\n@media (max-width: 1199.98px) {\n  .custum-body {\n    background-color: #2E2E2E;\n    height: 120px; } }\n\n@media (min-width: 1199.98px) {\n  .custum-body {\n    background-color: #2E2E2E;\n    height: 100px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2FuLXBoYW0tbm9pLWJhdC9DOlxceGFtcHBcXGh0ZG9jc1xcYXBwX3BpYW5vL3NyY1xcYXBwXFx1c2VyXFx0cmFuZy1jaHVcXHNhbi1waGFtLW5vaS1iYXRcXHNhbi1waGFtLW5vaS1iYXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSyxjQUFhLEVBR2pCOztBQVdEO0VBQ0ksbUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBYztFQUNkLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDNUI7O0FBRUQ7RUFDSSxtQkFBa0I7RUFDbEIsaUJBQWdCO0VBQ2hCLGVBQWU7RUFDZixlQUFjO0VBQ2QsdUNBQXNDLEVBQ3pDOztBQVVEO0VBR0k7SUFDSSwwQkFBeUI7SUFDekIsY0FBYSxFQUNoQixFQUFBOztBQUdMO0VBR0k7SUFDSSwwQkFBeUI7SUFDekIsY0FBYSxFQUNoQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2FuLXBoYW0tbm9pLWJhdC9zYW4tcGhhbS1ub2ktYmF0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1pbWFnZXsgXHJcbiAgICAgaGVpZ2h0OiAzMDBweDtcclxuICAgIC8vICB3aWR0aDogODAwcHg7XHJcbiAgICAvLyAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG59IFxyXG5cclxuLy8gLmN1c3RvbS10aXRsZXtcclxuLy8gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuLy8gICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbi8vICAgICBjb2xvcjogIzAwMCA7IFxyXG4vLyAgICAgZm9udC1zaXplOiAxMTAlO1xyXG4vLyAgICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuLy8gICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbi8vIH0gXHJcblxyXG4uY3VzdG9tLXByaWNle1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGNvbG9yOiAjZmY0NDQ0IDsgXHJcbiAgICBmb250LXNpemU6IDkwJTtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG59IFxyXG5cclxuLmN1c3RvbS1kZXNjcmlwdGlvbntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgICBjb2xvcjogIzM3NDc0RiA7IFxyXG4gICAgZm9udC1zaXplOiA4MCU7XHJcbiAgICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG59XHJcblxyXG4vLyAuaW1ne1xyXG4vLyAgICAgd2lkdGg6IDUwMHB4O1xyXG4vLyAgICAgaGVpZ2h0OiA0MDBweDtcclxuLy8gICAgIHBhZGRpbmctbGVmdDogNzdweDtcclxuLy8gfVxyXG5cclxuXHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4gIFxyXG4gICAgLmN1c3R1bS1ib2R5e1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMyRTJFMkU7XHJcbiAgICAgICAgaGVpZ2h0OiAxMjBweDtcclxuICAgIH1cclxufVxyXG5cclxuQG1lZGlhIChtaW4td2lkdGg6IDExOTkuOThweCkge1xyXG5cclxuICBcclxuICAgIC5jdXN0dW0tYm9keXtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMkUyRTJFO1xyXG4gICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuLy8gQG1lZGlhIChtYXgtd2lkdGg6IDM2MHB4KSB7XHJcblxyXG4gIFxyXG4vLyAgICAgLmN1c3R1bS1ib2R5e1xyXG4vLyAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMyRTJFMkU7XHJcbi8vICAgICAgICAgaGVpZ2h0OiAxNTBweDtcclxuLy8gICAgIH1cclxuLy8gfSJdfQ== */"

/***/ }),

/***/ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.ts ***!
  \*******************************************************************************/
/*! exports provided: SanPhamNoiBatComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SanPhamNoiBatComponent", function() { return SanPhamNoiBatComponent; });
/* harmony import */ var src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/api/piano.service */ "./src/app/api/piano.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SanPhamNoiBatComponent = /** @class */ (function () {
    function SanPhamNoiBatComponent(pianoService) {
        this.pianoService = pianoService;
    }
    SanPhamNoiBatComponent.prototype.ngOnInit = function () {
        this.getPiano03();
        this.getPiano33();
        this.getPiano31();
        this.getPiano42();
    };
    //getPiano vi tri thu 0 lay 1
    SanPhamNoiBatComponent.prototype.getPiano03 = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '25')
            .subscribe(function (data) {
            _this.listPiano03 = data;
        });
    };
    //getPiano vi tri thu 1 lay 2
    SanPhamNoiBatComponent.prototype.getPiano33 = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '26')
            .subscribe(function (data) {
            _this.listPiano33 = data;
            // this.slides = this.chunk(this.listPiano, 3);
        });
    };
    //getPiano vi tri thu 3 lay 1
    SanPhamNoiBatComponent.prototype.getPiano31 = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '27')
            .subscribe(function (data) {
            _this.listPiano31 = data;
        });
    };
    //getPiano vi tri thu 4 lay 1
    SanPhamNoiBatComponent.prototype.getPiano42 = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '28')
            .subscribe(function (data) {
            _this.listPiano42 = data;
        });
    };
    SanPhamNoiBatComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-san-pham-noi-bat',
            template: __webpack_require__(/*! ./san-pham-noi-bat.component.html */ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.html"),
            styles: [__webpack_require__(/*! ./san-pham-noi-bat.component.scss */ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__["PianoService"]])
    ], SanPhamNoiBatComponent);
    return SanPhamNoiBatComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"carouselExampleIndicators\" class=\"carousel slide \" data-ride=\"carousel\">\n  <ol class=\"carousel-indicators\">\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>\n  </ol>\n  <div class=\"carousel-inner \">\n    <div class=\"carousel-item active\">\n      <img class=\"d-block w-100 custom-slide img\" src=\"../../../../assets/img/11.png\" alt=\"Salem Piano\">\n\n      <div class=\"carousel-caption caption \">\n        <div class=\"slide-caption\">\n          <h3 class=\"h3-responsive text-left mt-5 caption1\">SALEM PIANO</h3>\n          <p class=\"text-left\">Salem piano mang đến cho học viên môi trường tốt nhất để phát triển , với cơ sở vật chất hiện đại giáo trình theo\n            chuẩn quốc tế cùng với đội ngũ giáo viên nhiệt huyết tận tâm </p>\n        </div>\n      </div>\n\n    </div>\n    <div class=\"carousel-item\">\n      <img class=\"d-block w-100 custom-slide img\" src=\"../../../../assets/img/2.png\" alt=\"Salem Piano\">\n      <div class=\"carousel-caption caption \">\n        <!-- <div class=\"slide-caption\">\n          <h3 class=\"h3-responsive text-left mt-5 caption1\">SALEM PIANO</h3>\n          <p class=\"text-left\">Đa dạng các mẫu keywoard với nhiều dòng sản phẩm cho khách hàng lựa chọn,phục vụ được cho những nhu cầu khác nhau\n            đến từ những thương hiệu tên tuổi.được người chơi tin dùng như Roland,Casio</p>\n        </div> -->\n      </div>\n    </div>\n    <div class=\"carousel-item img\">\n      <img class=\"d-block w-100 custom-slide\" src=\"../../../../assets/img/3.png\" alt=\"Salem Piano\">\n      <div class=\"carousel-caption caption \">\n        <!-- <div class=\"slide-caption\">\n          <h3 class=\"h3-responsive text-left mt-5 caption1\">SALEM PIANO</h3>\n          <p class=\"text-left\">Piano là một trong những nhạc cụ yêu thích nhất tại Việt Nam,Salem Piano cung cấp những chiếc đàn từ những thương\n            hiệu Kawai,Boston,Essex,Rimuller sẽ hài lòng quý khách</p>\n        </div> -->\n      </div>\n    </div>\n  </div>\n  <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">\n    <i class=\"fa fa-angle-double-left fa-3x white-text\"></i>\n    <span class=\"sr-only\">Previous</span>\n  </a>\n  <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">\n    <i class=\"fa fa-angle-double-right fa-3x white-text\"></i>\n    <span class=\"sr-only\">Next</span>\n  </a>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".caption {\n  font-weight: 500;\n  font-size: 110%;\n  font-family: \"Helvetica\", Times, serif;\n  color: white;\n  text-shadow: 40px;\n  padding-left: 10px;\n  margin-top: 20%; }\n\n@media (max-width: 1199.98px) {\n  .custom-slide {\n    height: 200px;\n    width: 100%; }\n  .slide-caption {\n    padding-left: 10px;\n    margin-top: 10px;\n    font-size: 12px;\n    font-family: \"Helvetica\", Times, serif;\n    line-height: 1.4;\n    height: 130px;\n    width: 240px;\n    background-color: rgba(62, 69, 81, 0.7); } }\n\n@media (min-width: 1199.98px) {\n  .img {\n    width: 1920px;\n    height: 550px; }\n  .slide-caption {\n    font-family: \"Helvetica\", Times, serif;\n    font-weight: 370;\n    padding-left: 20px;\n    padding-right: 20px;\n    height: 200px;\n    font-size: 17px;\n    width: 420px;\n    background-color: rgba(62, 69, 81, 0.7); }\n  .caption1 {\n    padding-top: 20px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2xpZGUvQzpcXHhhbXBwXFxodGRvY3NcXGFwcF9waWFuby9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxzbGlkZVxcc2xpZGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDSSxpQkFBZ0I7RUFDaEIsZ0JBQWU7RUFDZix1Q0FBc0M7RUFDdEMsYUFBWTtFQUNaLGtCQUFpQjtFQUNqQixtQkFBa0I7RUFDbEIsZ0JBQWUsRUFDbEI7O0FBRUQ7RUFFRTtJQUNFLGNBQWE7SUFDYixZQUFXLEVBQ1o7RUFFSDtJQUNFLG1CQUFrQjtJQUVsQixpQkFBZ0I7SUFDaEIsZ0JBQWU7SUFDZix1Q0FBc0M7SUFDdEMsaUJBQWdCO0lBSWhCLGNBQWE7SUFDYixhQUFZO0lBQ1osd0NBQXNDLEVBQ3ZDLEVBQUE7O0FBSUQ7RUFFQTtJQUNFLGNBQWE7SUFDYixjQUFhLEVBQ2Q7RUFFRDtJQUNFLHVDQUFzQztJQUN0QyxpQkFBZ0I7SUFDaEIsbUJBQWtCO0lBQ2xCLG9CQUFtQjtJQUNuQixjQUFhO0lBQ2IsZ0JBQWU7SUFDZixhQUFZO0lBQ1osd0NBQXNDLEVBQ3ZDO0VBQ0Q7SUFDRSxrQkFBaUIsRUFFbEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L3NsaWRlL3NsaWRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gLmN1c3RvbS1pbWFnZXtcclxuLy8gICAgIGhlaWdodDogNjUwcHg7XHJcbi8vICAgICB3aWR0aDogNTAlO1xyXG4vLyB9XHJcbi5jYXB0aW9ue1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMTEwJTtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB0ZXh0LXNoYWRvdzogNDBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIG1hcmdpbi10b3A6IDIwJTtcclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDExOTkuOThweCkge1xyXG5cclxuICAuY3VzdG9tLXNsaWRle1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAgIFxyXG4uc2xpZGUtY2FwdGlvbntcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgLy8gcGFkZGluZy10b3A6IDFweDtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgLy8gaGVpZ2h0OiAyNTBweDtcclxuICAvLyB3aWR0aDogNDAwcHg7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDYyLCA2OSwgODEsIDAuNyk7XHJcbiAgaGVpZ2h0OiAxMzBweDtcclxuICB3aWR0aDogMjQwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDYyLCA2OSwgODEsIDAuNyk7XHJcbn1cclxuIFxyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4uaW1ne1xyXG4gIHdpZHRoOiAxOTIwcHg7XHJcbiAgaGVpZ2h0OiA1NTBweDtcclxufVxyXG5cclxuLnNsaWRlLWNhcHRpb257XHJcbiAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICBmb250LXdlaWdodDogMzcwO1xyXG4gIHBhZGRpbmctbGVmdDogMjBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xyXG4gIGhlaWdodDogMjAwcHg7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG4gIHdpZHRoOiA0MjBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoNjIsIDY5LCA4MSwgMC43KTtcclxufVxyXG4uY2FwdGlvbjF7XHJcbiAgcGFkZGluZy10b3A6IDIwcHg7XHJcblxyXG59XHJcbn1cclxuXHJcblxyXG4vLyAuY3VzdG9tLXNsaWRle1xyXG4vLyAgICAgaGVpZ2h0OiAxMTAwcHg7XHJcbi8vIH0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.ts ***!
  \*********************************************************/
/*! exports provided: SlideComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SlideComponent", function() { return SlideComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SlideComponent = /** @class */ (function () {
    function SlideComponent() {
    }
    SlideComponent.prototype.ngOnInit = function () {
    };
    SlideComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-slide',
            template: __webpack_require__(/*! ./slide.component.html */ "./src/app/user/trang-chu/slide/slide.component.html"),
            styles: [__webpack_require__(/*! ./slide.component.scss */ "./src/app/user/trang-chu/slide/slide.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], SlideComponent);
    return SlideComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<hr>\n<h3 class=\"text-center black-text\" style=\"font-weight: 500\">TẤT CẢ SẢN PHẨM</h3>\n<br>\n\n<div>\n    <div class=\"row\">\n\n        <div class=\"col-md-4\" *ngFor=\"let piano of listPiano\">\n            <div class=\"card my-1\">\n                <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                    <img class=\"card-img-top img-fluid custom-image\" src=\"{{piano.hinhAnh}}\" alt=\"{{piano.tuKhoa}}\">\n                </a>\n                <div class=\"card-body custum-body\">\n                    <div class=\"row\">\n\n                        <div class=\"col\">\n                            <a title=\"piano\" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                                <p class=\"custom-title1 white-text\" style=\"font-size: 14px\">\n                                    <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> {{piano.tenSP}}</p>\n                                <p class=\"custom-title yellow-text\" style=\"font-size: 12px\"> Giá: {{piano.gia}} vnđ</p>\n                            </a>\n                        </div>\n                        <div class=\"col click\">\n                            <a class=\"  btn btn-sm btn-yellow \" routerLink=\"/user/trang-khac/chi-tiet-san-pham/{{piano.id}}\">\n                                <strong>Chi tiết</strong>\n                            </a>\n\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <br>\n\n    <!-- pagination -->\n    <!-- <nav aria-label=\"Page navigation example\">\n        <ul class=\"pagination pagination-circle pg-blue justify-content-center\">\n\n            <li class=\"page-item disabled\">\n                <a title=\"item\" class=\"page-link\" aria-label=\"Previous\" mdbWavesEffect>\n                    <span aria-hidden=\"true\">&laquo;</span>\n                    <span class=\"sr-only\">Previous</span>\n                </a>\n            </li>\n            <li class=\"page-item active\">\n                <a title=\"item\" class=\"page-link\" mdbWavesEffect>1</a>\n            </li>\n            <li class=\"page-item\">\n                <a title=\"item\" class=\"page-link\" mdbWavesEffect>2</a>\n            </li>\n            <li class=\"page-item\">\n                <a title=\"item\" class=\"page-link\" mdbWavesEffect>3</a>\n            </li>\n\n            <li class=\"page-item\">\n                <a title=\"item\" class=\"page-link\" aria-label=\"Next\" mdbWavesEffect>\n                    <span aria-hidden=\"true\">&raquo;</span>\n                    <span class=\"sr-only\">Next</span>\n                </a>\n            </li>\n\n        </ul>\n    </nav> -->"

/***/ }),

/***/ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".custom-card {\n  margin-bottom: 15px; }\n\n.custom-image {\n  height: 260px; }\n\n.custom-title {\n  font-weight: 500;\n  color: #000;\n  font-size: 110%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-title1 {\n  font-weight: 500;\n  color: #000;\n  font-size: 170%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-price {\n  text-align: center;\n  font-weight: 500;\n  color: #ff4444;\n  font-size: 90%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-description {\n  text-align: center;\n  font-weight: 300;\n  color: #37474F;\n  font-size: 80%;\n  font-family: \"Helvetica\", Times, serif; }\n\n@media (max-width: 1199.98px) {\n  .custum-body {\n    background-color: #2E2E2E;\n    height: 120px; } }\n\n@media (min-width: 1199.98px) {\n  .custum-body {\n    background-color: #2E2E2E;\n    height: 100px; } }\n\n.click {\n  padding-left: 45px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvdGF0LWNhLXNhbi1waGFtL0M6XFx4YW1wcFxcaHRkb2NzXFxhcHBfcGlhbm8vc3JjXFxhcHBcXHVzZXJcXHRyYW5nLWNodVxcdGF0LWNhLXNhbi1waGFtXFx0YXQtY2Etc2FuLXBoYW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQkFBbUIsRUFDdEI7O0FBRUQ7RUFDSSxjQUFhLEVBQ2hCOztBQUVEO0VBRU8saUJBQWdCO0VBQ2hCLFlBQVk7RUFDWixnQkFBZTtFQUNmLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDM0I7O0FBRUw7RUFFTyxpQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLGdCQUFlO0VBQ2YsdUNBQXNDO0VBQ3RDLDBCQUF5QixFQUMzQjs7QUFFTDtFQUNHLG1CQUFrQjtFQUNsQixpQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLGVBQWM7RUFDZCx1Q0FBc0M7RUFDdEMsMEJBQXlCLEVBQzNCOztBQUVEO0VBQ0csbUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBYztFQUNkLHVDQUFzQyxFQUN4Qzs7QUFFRDtFQUdJO0lBQ0ksMEJBQXlCO0lBQ3pCLGNBQWEsRUFDaEIsRUFBQTs7QUFHTDtFQUdJO0lBQ0ksMEJBQXlCO0lBQ3pCLGNBQWEsRUFDaEIsRUFBQTs7QUFHTDtFQUNJLG1CQUFrQixFQUNyQiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L3RhdC1jYS1zYW4tcGhhbS90YXQtY2Etc2FuLXBoYW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLWNhcmR7IFxyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufSBcclxuXHJcbi5jdXN0b20taW1hZ2V7IFxyXG4gICAgaGVpZ2h0OiAyNjBweDtcclxufSBcclxuXHJcbi5jdXN0b20tdGl0bGV7XHJcbiAgICAvLyAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgY29sb3I6ICMwMDAgOyBcclxuICAgICAgIGZvbnQtc2l6ZTogMTEwJTtcclxuICAgICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgfSBcclxuICAgIFxyXG4uY3VzdG9tLXRpdGxlMXtcclxuICAgIC8vICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICBjb2xvcjogIzAwMCA7IFxyXG4gICAgICAgZm9udC1zaXplOiAxNzAlO1xyXG4gICAgICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICB9IFxyXG5cclxuLmN1c3RvbS1wcmljZXtcclxuICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICBmb250LXdlaWdodDogNTAwO1xyXG4gICBjb2xvcjogI2ZmNDQ0NCA7IFxyXG4gICBmb250LXNpemU6IDkwJTtcclxuICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufSBcclxuXHJcbi5jdXN0b20tZGVzY3JpcHRpb257XHJcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgY29sb3I6ICMzNzQ3NEYgOyBcclxuICAgZm9udC1zaXplOiA4MCU7XHJcbiAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiAxMTk5Ljk4cHgpIHtcclxuXHJcbiAgXHJcbiAgICAuY3VzdHVtLWJvZHl7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzJFMkUyRTtcclxuICAgICAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4gIFxyXG4gICAgLmN1c3R1bS1ib2R5e1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMyRTJFMkU7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIH1cclxufVxyXG5cclxuLmNsaWNre1xyXG4gICAgcGFkZGluZy1sZWZ0OiA0NXB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.ts ***!
  \*****************************************************************************/
/*! exports provided: TatCaSanPhamComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TatCaSanPhamComponent", function() { return TatCaSanPhamComponent; });
/* harmony import */ var src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/api/piano.service */ "./src/app/api/piano.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var TatCaSanPhamComponent = /** @class */ (function () {
    function TatCaSanPhamComponent(pianoService) {
        this.pianoService = pianoService;
    }
    TatCaSanPhamComponent.prototype.ngOnInit = function () {
        this.getPiano();
    };
    //getPiano
    TatCaSanPhamComponent.prototype.getPiano = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '29')
            .subscribe(function (data) {
            _this.listPiano = data;
            console.log('p', _this.listPiano);
        });
    };
    TatCaSanPhamComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tat-ca-san-pham',
            template: __webpack_require__(/*! ./tat-ca-san-pham.component.html */ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.html"),
            styles: [__webpack_require__(/*! ./tat-ca-san-pham.component.scss */ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__["PianoService"]])
    ], TatCaSanPhamComponent);
    return TatCaSanPhamComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.html":
/*!***************************************************************!*\
  !*** ./src/app/user/trang-chu/tin-tuc/tin-tuc.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <br>\n  <h4 class=\"text-center black-text h3-responsive font-weight-bold my-5\">DỊCH VỤ</h4>\n  <hr>\n  <br>\n  <div class=\"row\">\n    <div class=\"col-lg-3 col-md-6 mb-md-0 mb-4\">\n      <div class=\"card mb-2\">\n        <img class=\"card-img-top imghinh img-fluid\" src=\"https://piano24h.vn/wp-content/uploads/2018/07/77282_0_body_5.jpg\"\n          alt=\"Card image cap\">\n        <div class=\"card-body body\">\n          <h4 class=\"card-title text-center font-weight-bold\">Dạy Nhạc</h4>\n          <p class=\"card-text text-center\">Salem Piano nhận dạy nhạc cho các bé từ 5 đến 15 tuổi</p>\n          <div class=\"row\">\n            <div class=\"col\">\n\n            </div>\n            <div class=\"col\">\n              <a class=\"btn buttons btn-md btn-rounded\" routerLink=\"/user/trang-khac/hoc-piano\">Xem</a>\n            </div>\n            <div class=\"col\">\n\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-lg-3 col-md-6 mb-md-0 mb-4\">\n      <div class=\"card mb-2\">\n        <img class=\"card-img-top imghinh img-fluid\" src=\"http://danpianohcm.com/wp-content/uploads/2018/04/1-17.jpg\"\n          alt=\"Card image cap\">\n        <div class=\"card-body body\">\n          <h4 class=\"card-title text-center font-weight-bold\">Sửa Chửa</h4>\n          <p class=\"card-text text-center\">Nơi sửa chửa đàn piano tốt nhất Đà Nẵng</p>\n          <div class=\"row\">\n            <div class=\"col\">\n\n            </div>\n            <div class=\"col\">\n              <a class=\"btn buttons btn-md btn-rounded\" routerLink=\"/user/trang-khac/sua-chua-dan\">Xem</a>\n            </div>\n            <div class=\"col\">\n\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"col-lg-3 col-md-6 mb-md-0 mb-4\">\n      <div class=\"card \">\n        <img class=\"card-img-top imghinh img-fluid\" src=\"http://musicfriend.vn/public/default/ckeditor/images/phongtapnhac_bandnhac_trong\"\n          alt=\"Card image cap\">\n        <div class=\"card-body body\">\n          <h4 class=\"card-title text-center font-weight-bold\">Cho Thuê Nhạc Cụ</h4>\n          <p class=\"card-text text-center\">Bạn muốn thuê nhạc cụ hãy ghé Salem Piano </p>\n          <div class=\"row\">\n            <div class=\"col\">\n\n            </div>\n            <div class=\"col\">\n              <a class=\"btn buttons btn-md btn-rounded\" routerLink=\"/user/trang-khac/cho-thue-nhac-cu\">Xem</a>\n            </div>\n            <div class=\"col\">\n\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"col-lg-3 col-md-6 mb-md-0 mb-4\">\n      <div class=\"card mb-2\">\n        <img class=\"card-img-top imghinh img-fluid\" src=\"http://radiology.com.vn/public/images/1463712010-Hoi-nghi-dien-quang-va-Y-hoc-hat-nhan-toan-quoc-lan-thu-14.jpg\"\n          alt=\"Card image cap\">\n        <div class=\"card-body body\">\n          <h4 class=\"card-title text-center font-weight-bold\">Tổ Chức Sự Kiện</h4>\n          <p class=\"card-text text-center\">Bạn muốn tổ chức sự kiện Salem Piano sẽ hổ trợ bạn</p>\n          <div class=\"row\">\n            <div class=\"col\">\n\n            </div>\n            <div class=\"col\">\n              <a class=\"btn buttons btn-md btn-rounded\" routerLink=\"/user/trang-khac/to-chuc-su-kien\">Xem</a>\n            </div>\n            <div class=\"col\">\n\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n\n    <!-- <div class=\"col\">\n      <h3 class=\"title\"> Salem piano nhận dạy đàn piano</h3>\n\n      <div class=\"view overlay zoom\">\n        <a routerLink=\"/user/trang-khac/hoc-piano\">\n          <img src=\"http://mycvietnam.com/images/day-piano-gia-re-tphcm.png\" class=\"img img-fluid \" alt=\"smaple image\">\n\n        </a>\n\n      </div>\n    </div>\n    <div class=\"col\">\n      <h3 class=\"title\"> Salem piano sản phẩm giá rẻ - chất lượng</h3>\n\n      <div class=\"view overlay zoom\">\n        <a routerLink=\"/user/trang-khac/san-pham\">\n          <img src=\"../../../../assets/img/pianosalem.jpg\" class=\"img img-fluid \" alt=\"smaple image\">\n\n        </a>\n\n      </div>\n    </div> -->\n  </div>\n  <h4 class=\"text-center black-text h3-responsive font-weight-bold my-5\">TIN TỨC - SỰ KIỆN</h4>\n  <hr>\n  <br>\n  <div class=\"row\">\n\n    <!-- Card deck -->\n    <div class=\"card-deck\">\n      <!-- Card -->\n      <div class=\"card mb-4\" *ngFor=\"let tin of tinMoi\">\n        <!--Card image-->\n        <div class=\"view overlay\">\n          <img class=\"card-img-top imghinh\" src=\"{{tin.hinhAnh}}\" alt=\"Card image cap\">\n          <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{tin.id}}\">\n            <div class=\"mask rgba-white-slight\"></div>\n          </a>\n        </div>\n        <!--Card content-->\n        <div class=\"card-body custom-body\">\n          <!--Title-->\n\n          <!--Text-->\n          <a class=\"custom-description\" routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{tin.id}}\">\n            {{tin.tieuDe}}\n          </a>\n          <div class=\"color\">\n            <i class=\"fa fa-star\"> </i>\n            <i class=\"fa fa-star\"> </i>\n            <i class=\"fa fa-star\"> </i>\n            <i class=\"fa fa-star\"> </i>\n            <i class=\"fa fa-star\"> </i>\n          </div>\n\n        </div>\n        <div class=\"footer\">\n          <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{tin.id}}\" class=\"white-text\">\n            <i class=\"fa fa-angle-double-right fa-1x white-text\"></i> Xem chi tiết</a>\n\n        </div>\n      </div>\n      <!-- Card -->\n\n    </div>\n    <!-- Card deck -->\n  </div>\n  <br>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/user/trang-chu/tin-tuc/tin-tuc.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".link {\n  text-align: center;\n  font-weight: 700;\n  color: white;\n  font-size: 210%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.img {\n  height: 80px;\n  width: 90px; }\n\n.imgtin {\n  height: 190px;\n  width: 300px; }\n\n.imghinh {\n  height: 220px; }\n\n.custom-image {\n  height: 300px; }\n\n.custom-title {\n  text-align: left;\n  font-weight: 350;\n  color: #37474F;\n  font-size: 152%;\n  font-family: \"Helvetica\", Times, serif; }\n\n.custom-new {\n  text-align: left;\n  font-weight: 350;\n  color: #004d40;\n  font-size: 152%;\n  font-family: \"Helvetica\", Times, serif; }\n\n.custom-price {\n  text-align: center;\n  font-weight: 500;\n  color: #ff4444;\n  font-size: 90%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n.custom-description {\n  text-align: left;\n  font-weight: 300;\n  color: #37474F;\n  font-size: 115%;\n  font-family: Times, serif; }\n\n.custom-body {\n  background-color: #e0e0e0; }\n\n.footer {\n  background-color: #212121;\n  padding-left: 20px;\n  padding-bottom: 5px;\n  padding-top: 5px; }\n\n.color {\n  color: #ffca28; }\n\n@media (min-width: 1199.98px) {\n  .img {\n    height: 300px;\n    width: 100%; }\n  .title {\n    font-weight: 700;\n    font-size: 160%;\n    font-family: \"Helvetica\", Times, serif; } }\n\n@media (max-width: 1199.98px) {\n  .img {\n    height: 100px;\n    width: 100%; }\n  .title {\n    font-weight: 700;\n    font-size: 100%;\n    font-family: \"Helvetica\", Times, serif; } }\n\n.body {\n  background-color: #f9fbe7; }\n\n.buttons {\n  background-color: #ffca28; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvdGluLXR1Yy9DOlxceGFtcHBcXGh0ZG9jc1xcYXBwX3BpYW5vL3NyY1xcYXBwXFx1c2VyXFx0cmFuZy1jaHVcXHRpbi10dWNcXHRpbi10dWMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBa0I7RUFDbkIsaUJBQWdCO0VBQ2hCLGFBQWE7RUFDYixnQkFBZTtFQUNmLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDM0I7O0FBQ0Q7RUFDSSxhQUFZO0VBQ1osWUFBVyxFQUNkOztBQUVEO0VBQ0ksY0FBYTtFQUNiLGFBQVksRUFDZjs7QUFFRDtFQUNJLGNBQWEsRUFFaEI7O0FBR0Q7RUFDSSxjQUFhLEVBQ2hCOztBQUVEO0VBQ0csaUJBQWdCO0VBQ2hCLGlCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZ0JBQWU7RUFDZix1Q0FBc0MsRUFFeEM7O0FBRUQ7RUFDSSxpQkFBZ0I7RUFDaEIsaUJBQWdCO0VBQ2hCLGVBQWdCO0VBQ2hCLGdCQUFlO0VBQ2YsdUNBQXNDLEVBRXhDOztBQUdGO0VBQ0csbUJBQWtCO0VBQ2xCLGlCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBYztFQUNkLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDM0I7O0FBRUQ7RUFDSSxpQkFBZ0I7RUFDaEIsaUJBQWdCO0VBQ2hCLGVBQWU7RUFDZixnQkFBZTtFQUNmLDBCQUF5QixFQUMzQjs7QUFFRDtFQUNJLDBCQUEyQixFQUM5Qjs7QUFDRDtFQUNHLDBCQUF5QjtFQUN4QixtQkFBa0I7RUFDbEIsb0JBQW1CO0VBQ25CLGlCQUFnQixFQUNuQjs7QUFFRDtFQUNHLGVBQWUsRUFDakI7O0FBR0Q7RUFFRztJQUNJLGNBQWE7SUFDYixZQUFXLEVBQ2Q7RUFDRDtJQUNFLGlCQUFnQjtJQUNoQixnQkFBZTtJQUNmLHVDQUFzQyxFQUN2QyxFQUFBOztBQUdMO0VBRUk7SUFDSSxjQUFhO0lBQ2IsWUFBVyxFQUNkO0VBQ0Q7SUFDSSxpQkFBZ0I7SUFDaEIsZ0JBQWU7SUFDZix1Q0FBc0MsRUFDekMsRUFBQTs7QUFHTDtFQUNJLDBCQUEwQixFQUM3Qjs7QUFFRDtFQUNJLDBCQUEwQixFQUM3QiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L3Rpbi10dWMvdGluLXR1Yy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saW5re1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICBmb250LXdlaWdodDogNzAwO1xyXG4gICBjb2xvcjogd2hpdGUgOyBcclxuICAgZm9udC1zaXplOiAyMTAlO1xyXG4gICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG59XHJcbi5pbWd7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICB3aWR0aDogOTBweDtcclxufVxyXG5cclxuLmltZ3RpbntcclxuICAgIGhlaWdodDogMTkwcHg7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbn1cclxuXHJcbi5pbWdoaW5oe1xyXG4gICAgaGVpZ2h0OiAyMjBweDtcclxuICAgIC8vIHdpZHRoOiAzNTBweDtcclxufVxyXG5cclxuXHJcbi5jdXN0b20taW1hZ2V7IFxyXG4gICAgaGVpZ2h0OiAzMDBweDtcclxufSBcclxuXHJcbi5jdXN0b20tdGl0bGV7XHJcbiAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgIGZvbnQtd2VpZ2h0OiAzNTA7XHJcbiAgIGNvbG9yOiAjMzc0NzRGIDsgXHJcbiAgIGZvbnQtc2l6ZTogMTUyJTtcclxuICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuLy8gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufSBcclxuXHJcbi5jdXN0b20tbmV3e1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGZvbnQtd2VpZ2h0OiAzNTA7XHJcbiAgICBjb2xvcjogIzAwNGQ0MCAgOyBcclxuICAgIGZvbnQtc2l6ZTogMTUyJTtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAvLyAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gfSBcclxuIFxyXG5cclxuLmN1c3RvbS1wcmljZXtcclxuICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICBmb250LXdlaWdodDogNTAwO1xyXG4gICBjb2xvcjogI2ZmNDQ0NCA7IFxyXG4gICBmb250LXNpemU6IDkwJTtcclxuICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufSBcclxuXHJcbi5jdXN0b20tZGVzY3JpcHRpb257XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgIGNvbG9yOiAjMzc0NzRGIDsgXHJcbiAgICBmb250LXNpemU6IDExNSU7XHJcbiAgICBmb250LWZhbWlseTogVGltZXMsIHNlcmlmO1xyXG4gfVxyXG5cclxuIC5jdXN0b20tYm9keXtcclxuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTBlMGUwICA7XHJcbiB9XHJcbiAuZm9vdGVye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzIxMjEyMTtcclxuICAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gfVxyXG5cclxuIC5jb2xvcntcclxuICAgIGNvbG9yOiAgI2ZmY2EyODtcclxuIH1cclxuXHJcblxyXG4gQG1lZGlhIChtaW4td2lkdGg6IDExOTkuOThweCkge1xyXG5cclxuICAgIC5pbWd7XHJcbiAgICAgICAgaGVpZ2h0OiAzMDBweDtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIC50aXRsZXtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgZm9udC1zaXplOiAxNjAlO1xyXG4gICAgICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4gICAgLmltZ3tcclxuICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgLnRpdGxle1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMDAlO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5ib2R5e1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogICNmOWZiZTc7XHJcbn1cclxuXHJcbi5idXR0b25ze1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmY2EyOCA7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/tin-tuc/tin-tuc.component.ts ***!
  \*************************************************************/
/*! exports provided: TinTucComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TinTucComponent", function() { return TinTucComponent; });
/* harmony import */ var src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/api/piano.service */ "./src/app/api/piano.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var TinTucComponent = /** @class */ (function () {
    function TinTucComponent(pianoService) {
        this.pianoService = pianoService;
    }
    TinTucComponent.prototype.ngOnInit = function () {
        this.getTinMoi();
    };
    //lay tin moi
    TinTucComponent.prototype.getTinMoi = function () {
        var _this = this;
        this.pianoService.excuteAllByWhat({}, '17')
            .subscribe(function (data) {
            _this.tinMoi = data;
        });
    };
    TinTucComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tin-tuc',
            template: __webpack_require__(/*! ./tin-tuc.component.html */ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.html"),
            styles: [__webpack_require__(/*! ./tin-tuc.component.scss */ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_api_piano_service__WEBPACK_IMPORTED_MODULE_0__["PianoService"]])
    ], TinTucComponent);
    return TinTucComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.html":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-slide></app-slide>\r\n<div class=\"container\">\r\n    <div class=\"row\">\r\n\r\n        <div class=\"col\">\r\n            <app-uy-tin></app-uy-tin>\r\n            <app-san-pham-noi-bat></app-san-pham-noi-bat>\r\n            <!-- <app-san-pham-ban-chay></app-san-pham-ban-chay> -->\r\n            <app-tat-ca-san-pham></app-tat-ca-san-pham>\r\n            <app-tin-tuc></app-tin-tuc>\r\n           \r\n        </div>\r\n    </div>\r\n</div>\r\n<div>\r\n    <app-video></app-video>\r\n</div>\r\n\r\n<div class=\"container\">\r\n    <app-danh-gia-khach></app-danh-gia-khach>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sidebar-fixed {\n  height: 100vh;\n  width: 270px;\n  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);\n  z-index: 1050;\n  background-color: #fff;\n  padding: 1.5rem;\n  padding-top: 0; }\n\n.sidebar-fixed .list-group .active {\n  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);\n  border-radius: 5px; }\n\n.sidebar-fixed .logo-wrapper {\n  padding: 2.5rem; }\n\n.sidebar-fixed .logo-wrapper img {\n  max-height: 50px; }\n\n@media (min-width: 1200px) {\n  .navbar,\n  .page-footer,\n  main {\n    padding-left: 270px; } }\n\n@media (max-width: 1199.98px) {\n  .sidebar-fixed {\n    display: none; } }\n\n/* custom tree styles */\n\n.custom-card {\n  width: 300px;\n  float: left;\n  padding-bottom: 500px;\n  margin-right: 352px;\n  position: fixed; }\n\n/* custom tree styles */\n\n.custom-tree.wj-treeview {\n  color: #5c6bc0;\n  padding-top: 35px;\n  font-size: 75%;\n  font-family: \"Helvetica\", Times, serif;\n  font-weight: 600; }\n\n/* level 0 and deeper nodes */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-node {\n  font-size: 100%; }\n\n/* level 1 and deeper nodes (larger font, vertical line along the left) */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-node,\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist {\n  font-size: 100%;\n  border-left: 4px solid rgba(128, 4, 77, 0.3); }\n\n/* level 2 and deeper nodes (smaller font, thinner border) */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist > .wj-node,\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist > .wj-nodelist {\n  font-size: 100%;\n  border-left: 2px solid rgba(128, 4, 77, 0.3); }\n\n/* expanded node glyph */\n\n.custom-tree.wj-treeview .wj-nodelist .wj-node:before {\n  content: \"\\e114\";\n  font-family: 'Glyphicons Halflings';\n  top: 4px;\n  border: none;\n  opacity: .3;\n  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }\n\n/* collapsed node glyph */\n\n.custom-tree.wj-treeview .wj-nodelist .wj-node.wj-state-collapsed:before,\n.custom-tree.wj-treeview .wj-nodelist .wj-node.wj-state-collapsing:before {\n  -webkit-transform: rotate(-180deg);\n      -ms-transform: rotate(-180deg);\n          transform: rotate(-180deg);\n  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvQzpcXHhhbXBwXFxodGRvY3NcXGFwcF9waWFuby9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFx0cmFuZy1jaHUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFhO0VBQ2IsYUFBWTtFQUVaLDhFQUE2RTtFQUM3RSxjQUFhO0VBQ2IsdUJBQXNCO0VBQ3RCLGdCQUFlO0VBQ2YsZUFBYyxFQUFHOztBQUNqQjtFQUVFLDhFQUE2RTtFQUU3RSxtQkFBa0IsRUFBRzs7QUFDdkI7RUFDRSxnQkFBZSxFQUFHOztBQUNsQjtFQUNFLGlCQUFnQixFQUFHOztBQUV6QjtFQUNFOzs7SUFHRSxvQkFBbUIsRUFBRyxFQUFBOztBQUUxQjtFQUNFO0lBQ0UsY0FBYSxFQUFHLEVBQUE7O0FBSXRCLHdCQUF3Qjs7QUFDeEI7RUFHSSxhQUFXO0VBQ1gsWUFBVztFQUNYLHNCQUFxQjtFQUNyQixvQkFBbUI7RUFDbkIsZ0JBQWUsRUFDbEI7O0FBRUQsd0JBQXdCOztBQUN4QjtFQUNJLGVBQWU7RUFDZixrQkFBaUI7RUFDakIsZUFBYztFQUNkLHVDQUFzQztFQUN0QyxpQkFBZ0IsRUFDbkI7O0FBRUQsOEJBQThCOztBQUM5QjtFQUNJLGdCQUFlLEVBQ2xCOztBQUVELDBFQUEwRTs7QUFDMUU7O0VBRUksZ0JBQWU7RUFDZiw2Q0FBNEMsRUFDL0M7O0FBRUQsNkRBQTZEOztBQUM3RDs7RUFFSSxnQkFBZTtFQUNmLDZDQUE0QyxFQUMvQzs7QUFFRCx5QkFBeUI7O0FBQ3pCO0VBQ0ksaUJBQWdCO0VBQ2hCLG9DQUFtQztFQUNuQyxTQUFRO0VBQ1IsYUFBWTtFQUNaLFlBQVc7RUFDWCxrREFBMkMsRUFDOUM7O0FBRUQsMEJBQTBCOztBQUMxQjs7RUFFSSxtQ0FBMEI7TUFBMUIsK0JBQTBCO1VBQTFCLDJCQUEwQjtFQUMxQixrREFBMkMsRUFDOUMiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS90cmFuZy1jaHUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2lkZWJhci1maXhlZCB7XHJcbiAgICBoZWlnaHQ6IDEwMHZoO1xyXG4gICAgd2lkdGg6IDI3MHB4O1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDJweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMTYpLCAwIDJweCAxMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4xNiksIDAgMnB4IDEwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xyXG4gICAgei1pbmRleDogMTA1MDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAxLjVyZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMDsgfVxyXG4gICAgLnNpZGViYXItZml4ZWQgLmxpc3QtZ3JvdXAgLmFjdGl2ZSB7XHJcbiAgICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAycHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjE2KSwgMCAycHggMTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xMik7XHJcbiAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4xNiksIDAgMnB4IDEwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xyXG4gICAgICAtd2Via2l0LWJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNXB4OyB9XHJcbiAgICAuc2lkZWJhci1maXhlZCAubG9nby13cmFwcGVyIHtcclxuICAgICAgcGFkZGluZzogMi41cmVtOyB9XHJcbiAgICAgIC5zaWRlYmFyLWZpeGVkIC5sb2dvLXdyYXBwZXIgaW1nIHtcclxuICAgICAgICBtYXgtaGVpZ2h0OiA1MHB4OyB9XHJcbiAgXHJcbiAgQG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCkge1xyXG4gICAgLm5hdmJhcixcclxuICAgIC5wYWdlLWZvb3RlcixcclxuICAgIG1haW4ge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDI3MHB4OyB9IH1cclxuICBcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XHJcbiAgICAuc2lkZWJhci1maXhlZCB7XHJcbiAgICAgIGRpc3BsYXk6IG5vbmU7IH0gfVxyXG4gIFxyXG5cclxuIFxyXG4vKiBjdXN0b20gdHJlZSBzdHlsZXMgKi9cclxuLmN1c3RvbS1jYXJkICB7XHJcbiAgICAvLyBjb2xvcjogIzgwMDQ0ZDtcclxuICAgIC8vIG1hcmdpbi10b3A6IDUycHg7XHJcbiAgICB3aWR0aDozMDBweDtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDUwMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAzNTJweDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxufVxyXG5cclxuLyogY3VzdG9tIHRyZWUgc3R5bGVzICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAge1xyXG4gICAgY29sb3I6ICM1YzZiYzAgO1xyXG4gICAgcGFkZGluZy10b3A6IDM1cHg7IFxyXG4gICAgZm9udC1zaXplOiA3NSU7XHJcbiAgICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5cclxuLyogbGV2ZWwgMCBhbmQgZGVlcGVyIG5vZGVzICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZSAge1xyXG4gICAgZm9udC1zaXplOiAxMDAlO1xyXG59XHJcblxyXG4vKiBsZXZlbCAxIGFuZCBkZWVwZXIgbm9kZXMgKGxhcmdlciBmb250LCB2ZXJ0aWNhbCBsaW5lIGFsb25nIHRoZSBsZWZ0KSAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0ID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgIHtcclxuICAgIGZvbnQtc2l6ZTogMTAwJTtcclxuICAgIGJvcmRlci1sZWZ0OiA0cHggc29saWQgcmdiYSgxMjgsIDQsIDc3LCAwLjMpO1xyXG59XHJcblxyXG4vKiBsZXZlbCAyIGFuZCBkZWVwZXIgbm9kZXMgKHNtYWxsZXIgZm9udCwgdGhpbm5lciBib3JkZXIpICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGVsaXN0ICB7XHJcbiAgICBmb250LXNpemU6IDEwMCU7XHJcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHJnYmEoMTI4LCA0LCA3NywgMC4zKTtcclxufVxyXG5cclxuLyogZXhwYW5kZWQgbm9kZSBnbHlwaCAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0IC53ai1ub2RlOmJlZm9yZSAgeyBcclxuICAgIGNvbnRlbnQ6IFwiXFxlMTE0XCI7XHJcbiAgICBmb250LWZhbWlseTogJ0dseXBoaWNvbnMgSGFsZmxpbmdzJztcclxuICAgIHRvcDogNHB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgb3BhY2l0eTogLjM7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjNzIGN1YmljLWJlemllciguNCwwLC4yLDEpO1xyXG59XHJcblxyXG4vKiBjb2xsYXBzZWQgbm9kZSBnbHlwaCAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0IC53ai1ub2RlLndqLXN0YXRlLWNvbGxhcHNlZDpiZWZvcmUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgLndqLW5vZGUud2otc3RhdGUtY29sbGFwc2luZzpiZWZvcmUgIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKC0xODBkZWcpO1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIC4zcyBjdWJpYy1iZXppZXIoLjQsMCwuMiwxKTtcclxufVxyXG4gICAgIl19 */"

/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.ts ***!
  \*******************************************************/
/*! exports provided: TrangChuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrangChuComponent", function() { return TrangChuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/admin/extral-admin/common/login-cookie */ "./src/app/admin/extral-admin/common/login-cookie.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



// import { Router } from '@angular/router';
var TrangChuComponent = /** @class */ (function () {
    function TrangChuComponent(router, loginCookie) {
        this.router = router;
        this.loginCookie = loginCookie;
    }
    TrangChuComponent.prototype.ngOnInit = function () {
    };
    TrangChuComponent.prototype.ngAfterViewInit = function () {
    };
    TrangChuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-trang-chu',
            template: __webpack_require__(/*! ./trang-chu.component.html */ "./src/app/user/trang-chu/trang-chu.component.html"),
            styles: [__webpack_require__(/*! ./trang-chu.component.scss */ "./src/app/user/trang-chu/trang-chu.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_2__["LoginCookie"]])
    ], TrangChuComponent);
    return TrangChuComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.module.ts":
/*!****************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.module.ts ***!
  \****************************************************/
/*! exports provided: TrangChuModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrangChuModule", function() { return TrangChuModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./trang-chu.component */ "./src/app/user/trang-chu/trang-chu.component.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/esm5/angular-bootstrap-md.es5.js");
/* harmony import */ var _slide_slide_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./slide/slide.component */ "./src/app/user/trang-chu/slide/slide.component.ts");
/* harmony import */ var _uy_tin_uy_tin_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./uy-tin/uy-tin.component */ "./src/app/user/trang-chu/uy-tin/uy-tin.component.ts");
/* harmony import */ var _san_pham_noi_bat_san_pham_noi_bat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./san-pham-noi-bat/san-pham-noi-bat.component */ "./src/app/user/trang-chu/san-pham-noi-bat/san-pham-noi-bat.component.ts");
/* harmony import */ var _san_pham_ban_chay_san_pham_ban_chay_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./san-pham-ban-chay/san-pham-ban-chay.component */ "./src/app/user/trang-chu/san-pham-ban-chay/san-pham-ban-chay.component.ts");
/* harmony import */ var _tat_ca_san_pham_tat_ca_san_pham_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./tat-ca-san-pham/tat-ca-san-pham.component */ "./src/app/user/trang-chu/tat-ca-san-pham/tat-ca-san-pham.component.ts");
/* harmony import */ var _danh_gia_khach_danh_gia_khach_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./danh-gia-khach/danh-gia-khach.component */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts");
/* harmony import */ var _tin_tuc_tin_tuc_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./tin-tuc/tin-tuc.component */ "./src/app/user/trang-chu/tin-tuc/tin-tuc.component.ts");
/* harmony import */ var _video_video_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./video/video.component */ "./src/app/user/trang-chu/video/video.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};














var routing = [{
        path: '', component: _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"],
        children: [
        // {
        //   path: 'quan-ly-nhap-diem/:khoi', component: QuanLyNhapDiemComponent
        // },
        // { path: 'cai-dat-cot-diem/:khoi', component: CaiDatCotDiemComponent },
        // { path: 'quan-ly-ngay-nghi/:khoi', component: QuanLyNgayNghiComponent },
        // { path: 'quan-ly-hoc-sinh/quan-ly-chuyen-lop', component: QuanLyHocSinhComponent },
        // {
        //   path: 'login', component: LoginComponent,
        //   children: [
        //     { path: 'login', component: LogInComponent },
        //     { path: 'forget-password', component: ForgetPasswordComponent },
        //   ]
        // },
        ]
    }];
var TrangChuModule = /** @class */ (function () {
    function TrangChuModule() {
    }
    TrangChuModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"],
                _slide_slide_component__WEBPACK_IMPORTED_MODULE_6__["SlideComponent"],
                _uy_tin_uy_tin_component__WEBPACK_IMPORTED_MODULE_7__["UyTinComponent"],
                _san_pham_noi_bat_san_pham_noi_bat_component__WEBPACK_IMPORTED_MODULE_8__["SanPhamNoiBatComponent"],
                _san_pham_ban_chay_san_pham_ban_chay_component__WEBPACK_IMPORTED_MODULE_9__["SanPhamBanChayComponent"],
                _tat_ca_san_pham_tat_ca_san_pham_component__WEBPACK_IMPORTED_MODULE_10__["TatCaSanPhamComponent"],
                _danh_gia_khach_danh_gia_khach_component__WEBPACK_IMPORTED_MODULE_11__["DanhGiaKhachComponent"],
                _tin_tuc_tin_tuc_component__WEBPACK_IMPORTED_MODULE_12__["TinTucComponent"],
                _video_video_component__WEBPACK_IMPORTED_MODULE_13__["VideoComponent"],
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routing),
                angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_5__["MDBBootstrapModule"].forRoot(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            ],
            entryComponents: [
                _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"]
            ],
            exports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]]
        })
    ], TrangChuModule);
    return TrangChuModule;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/uy-tin/uy-tin.component.html":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/uy-tin/uy-tin.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row text-center custom-body\">\r\n    <div class=\"col icon\">\r\n        <div class=\"row\">\r\n            <div class=\"col-sm-2\">\r\n                <i class=\"fa fa-cc-visa fa-3x color\"></i>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n                <h6 class=\"color font-weight-bold\">TRẢ GÓP</h6>\r\n                <P class=\"color\" style=\"font-size: 14px\">Mua hàng lãi xuất 0%</P>\r\n            </div>\r\n            <div class=\"col-sm-2\">\r\n                <i class=\"fa fa-truck fa-3x color\"></i>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n                <h6 class=\"color font-weight-bold\">VẬN CHUYỂN</h6>\r\n                <P class=\"color\" style=\"font-size: 14px\">Chuyên nghiệp - tốc độ</P>\r\n            </div>\r\n\r\n        </div>\r\n    </div>\r\n    <div class=\"col icon\">\r\n        <div class=\"row\">\r\n            <div class=\"col-sm-2\">\r\n                <i class=\"fa fa-gear fa-3x color\"></i>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n                <h6 class=\"color font-weight-bold\">BẢO HÀNH</h6>\r\n                <P class=\"color\" style=\"font-size: 14px\">Hiệu quả - chất lượng</P>\r\n            </div>\r\n            <div class=\"col-sm-2\">\r\n                <i class=\"fa fa-star fa-3x color\"></i>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n                <h6 class=\"color font-weight-bold\">SẢN PHẨM</h6>\r\n                <P class=\"color\" style=\"font-size: 14px\">Giá rẻ - chính hãng</P>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/uy-tin/uy-tin.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/uy-tin/uy-tin.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".cascading-admin-card {\n  margin-top: 20px; }\n\n.cascading-admin-card .admin-up {\n  margin-left: 4%;\n  margin-right: 4%;\n  margin-top: -20px; }\n\n.cascading-admin-card .admin-up .fa {\n  padding: 1.7rem;\n  font-size: 2rem;\n  color: #fff;\n  text-align: left;\n  margin-right: 1rem;\n  border-radius: 3px; }\n\n.cascading-admin-card .admin-up .data {\n  float: right;\n  margin-top: 2rem;\n  text-align: right; }\n\n.cascading-admin-card .admin-up .data p {\n  color: #999999;\n  font-size: 12px; }\n\n.classic-admin-card .card-body {\n  color: #fff;\n  margin-bottom: 0;\n  padding: 0.9rem; }\n\n.classic-admin-card .card-body p {\n  font-size: 13px;\n  opacity: 0.7;\n  margin-bottom: 0; }\n\n.classic-admin-card .card-body h4 {\n  margin-top: 10px; }\n\n.classic-admin-card .card-body .float-right .fa {\n  font-size: 3rem;\n  opacity: 0.5; }\n\n.classic-admin-card .progress {\n  margin: 0;\n  opacity: 0.7; }\n\n.cascading-admin-card .admin-up .fa {\n  box-shadow: 0 2px 9px 0 rgba(0, 0, 0, 0.2), 0 2px 13px 0 rgba(0, 0, 0, 0.19); }\n\n.custom-body {\n  background-color: #212121; }\n\n.icon {\n  padding-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px; }\n\n.color {\n  color: #ffca28; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvdXktdGluL0M6XFx4YW1wcFxcaHRkb2NzXFxhcHBfcGlhbm8vc3JjXFxhcHBcXHVzZXJcXHRyYW5nLWNodVxcdXktdGluXFx1eS10aW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBZ0IsRUFBRzs7QUFDbkI7RUFDRSxnQkFBZTtFQUNmLGlCQUFnQjtFQUNoQixrQkFBaUIsRUFBRzs7QUFDcEI7RUFDRSxnQkFBZTtFQUNmLGdCQUFlO0VBQ2YsWUFBVztFQUNYLGlCQUFnQjtFQUNoQixtQkFBa0I7RUFDbEIsbUJBQWtCLEVBQUc7O0FBQ3ZCO0VBQ0UsYUFBWTtFQUNaLGlCQUFnQjtFQUNoQixrQkFBaUIsRUFBRzs7QUFDcEI7RUFDRSxlQUFjO0VBQ2QsZ0JBQWUsRUFBRzs7QUFFMUI7RUFDRSxZQUFXO0VBQ1gsaUJBQWdCO0VBQ2hCLGdCQUFlLEVBQUc7O0FBQ2xCO0VBQ0UsZ0JBQWU7RUFDZixhQUFZO0VBQ1osaUJBQWdCLEVBQUc7O0FBQ3JCO0VBQ0UsaUJBQWdCLEVBQUc7O0FBQ3JCO0VBQ0UsZ0JBQWU7RUFDZixhQUFZLEVBQUc7O0FBRW5CO0VBQ0UsVUFBUztFQUNULGFBQVksRUFBRzs7QUFHakI7RUFFRSw2RUFBNEUsRUFDN0U7O0FBR0Q7RUFDRSwwQkFBeUIsRUFFMUI7O0FBR0Q7RUFDRSxrQkFBaUI7RUFFakIsbUJBQWtCO0VBQ2xCLG9CQUVGLEVBQUM7O0FBR0Q7RUFDQyxlQUFlLEVBQ2YiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS91eS10aW4vdXktdGluLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhc2NhZGluZy1hZG1pbi1jYXJkIHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7IH1cclxuICAgIC5jYXNjYWRpbmctYWRtaW4tY2FyZCAuYWRtaW4tdXAge1xyXG4gICAgICBtYXJnaW4tbGVmdDogNCU7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogNCU7XHJcbiAgICAgIG1hcmdpbi10b3A6IC0yMHB4OyB9XHJcbiAgICAgIC5jYXNjYWRpbmctYWRtaW4tY2FyZCAuYWRtaW4tdXAgLmZhIHtcclxuICAgICAgICBwYWRkaW5nOiAxLjdyZW07XHJcbiAgICAgICAgZm9udC1zaXplOiAycmVtO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxcmVtO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDsgfVxyXG4gICAgICAuY2FzY2FkaW5nLWFkbWluLWNhcmQgLmFkbWluLXVwIC5kYXRhIHtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMnJlbTtcclxuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDsgfVxyXG4gICAgICAgIC5jYXNjYWRpbmctYWRtaW4tY2FyZCAuYWRtaW4tdXAgLmRhdGEgcCB7XHJcbiAgICAgICAgICBjb2xvcjogIzk5OTk5OTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDsgfVxyXG4gIFxyXG4gIC5jbGFzc2ljLWFkbWluLWNhcmQgLmNhcmQtYm9keSB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICBwYWRkaW5nOiAwLjlyZW07IH1cclxuICAgIC5jbGFzc2ljLWFkbWluLWNhcmQgLmNhcmQtYm9keSBwIHtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICBvcGFjaXR5OiAwLjc7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDA7IH1cclxuICAgIC5jbGFzc2ljLWFkbWluLWNhcmQgLmNhcmQtYm9keSBoNCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7IH1cclxuICAgIC5jbGFzc2ljLWFkbWluLWNhcmQgLmNhcmQtYm9keSAuZmxvYXQtcmlnaHQgLmZhIHtcclxuICAgICAgZm9udC1zaXplOiAzcmVtO1xyXG4gICAgICBvcGFjaXR5OiAwLjU7IH1cclxuICBcclxuICAuY2xhc3NpYy1hZG1pbi1jYXJkIC5wcm9ncmVzcyB7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBvcGFjaXR5OiAwLjc7IH1cclxuICBcclxuICAgIFxyXG4gIC5jYXNjYWRpbmctYWRtaW4tY2FyZCAuYWRtaW4tdXAgLmZhIHtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAycHggOXB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDJweCAxM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjE5KTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDlweCAwIHJnYmEoMCwgMCwgMCwgMC4yKSwgMCAycHggMTNweCAwIHJnYmEoMCwgMCwgMCwgMC4xOSk7XHJcbiAgfVxyXG5cclxuXHJcbiAgLmN1c3RvbS1ib2R5e1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzIxMjEyMTtcclxuICAgXHJcbiAgfVxyXG4gXHJcblxyXG4gIC5pY29ue1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICAvLyBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTBweFxyXG4gIFxyXG4gIH1cclxuXHJcblxyXG4gIC5jb2xvcntcclxuICAgY29sb3I6ICAjZmZjYTI4O1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/uy-tin/uy-tin.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/uy-tin/uy-tin.component.ts ***!
  \***********************************************************/
/*! exports provided: UyTinComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UyTinComponent", function() { return UyTinComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var UyTinComponent = /** @class */ (function () {
    function UyTinComponent() {
    }
    UyTinComponent.prototype.ngOnInit = function () {
    };
    UyTinComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-uy-tin',
            template: __webpack_require__(/*! ./uy-tin.component.html */ "./src/app/user/trang-chu/uy-tin/uy-tin.component.html"),
            styles: [__webpack_require__(/*! ./uy-tin.component.scss */ "./src/app/user/trang-chu/uy-tin/uy-tin.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], UyTinComponent);
    return UyTinComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/video/video.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/video/video.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <div class=\"custom container-fluid\">\n    <div class=\"row\">\n      <div class=\"col-lg-2 col-md-6 mb-lg-0 mb-5\">\n\n      </div>\n\n      <div class=\"col-lg-4 col-md-6 mb-lg-0 mb-5\">\n        <!-- 4:3 aspect ratio -->\n        <iframe class=\"img-fluid iframe\" src=\"https://www.youtube.com/embed/Q_iHCU8-vw8\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\"\n          allowfullscreen></iframe>\n      </div>\n\n      <div class=\"col-lg-4 col-md-6 mb-lg-0 mb-5\">\n        <h3 class=\"font-weight-bold\">SALEM PIANO 20 NĂM PHÁT TRIỂN</h3>\n        <p class=\"font-weight-normal\">\n          <i class=\"fa fa-angle-double-right fa-1x blue-text\"></i> Hơn 70 đại lý lớn nhỏ tại các tỉnh thành việt nam</p>\n        <p class=\"font-weight-normal\">\n          <i class=\"fa fa-angle-double-right fa-1x blue-text\"></i> Cam kết đem lại lợi ích tốt nhất cho khách hàng</p>\n        <p class=\"font-weight-normal\">\n          <i class=\"fa fa-angle-double-right fa-1x blue-text\"></i> Salem Music Shool với hệ thống giáo trình theo tiêu chuẩn Quốc Tế</p>\n        <p class=\"font-weight-normal\">\n          <i class=\"fa fa-angle-double-right fa-1x blue-text\"></i> Dịch vụ cho thê âm nhạc cụ,âm thanh ánh sáng lớn nhất</p>\n      </div>\n\n      <div class=\"col-lg-2 col-md-6 mb-lg-0 mb-5\">\n\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/video/video.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/video/video.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".custom-body {\n  background-color: #fdd835; }\n\n.custom {\n  background-color: #fdd835;\n  padding-top: 40px;\n  padding-bottom: 40px; }\n\n@media (min-width: 1199.98px) {\n  .iframe {\n    height: 300px;\n    width: 100%; } }\n\n@media (max-width: 1199.98px) {\n  .iframe {\n    height: 300px;\n    width: 100%; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvdmlkZW8vQzpcXHhhbXBwXFxodGRvY3NcXGFwcF9waWFuby9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFx2aWRlb1xcdmlkZW8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBa0MsRUFFckM7O0FBQ0Q7RUFDSSwwQkFBa0M7RUFDbEMsa0JBQWlCO0VBQ2pCLHFCQUFvQixFQUN2Qjs7QUFTRDtFQUlJO0lBQ0ksY0FBYTtJQUNiLFlBQVksRUFDZixFQUFBOztBQUdMO0VBSUk7SUFDSSxjQUFhO0lBQ2IsWUFBWSxFQUNmLEVBQUEiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS92aWRlby92aWRlby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tYm9keXtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZGQ4MzUgICAgICAgICA7XHJcbiAgICAvL2hlaWdodDogNTAwcHg7XHJcbn1cclxuLmN1c3RvbXtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZGQ4MzUgICAgICAgICA7XHJcbiAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA0MHB4O1xyXG59XHJcblxyXG4vLyAuaWZyYW1le1xyXG4vLyAgICAgd2lkdGg6IDEwMCU7XHJcbi8vICAgICBoZWlnaHQ6IDM1MHB4O1xyXG4vLyB9XHJcblxyXG5cclxuXHJcbkBtZWRpYSAobWluLXdpZHRoOiAxMTk5Ljk4cHgpIHtcclxuXHJcbiAgXHJcblxyXG4gICAgLmlmcmFtZXtcclxuICAgICAgICBoZWlnaHQ6IDMwMHB4OyAgXHJcbiAgICAgICAgd2lkdGg6IDEwMCUgOyAgXHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiAxMTk5Ljk4cHgpIHtcclxuXHJcbiAgXHJcblxyXG4gICAgLmlmcmFtZXtcclxuICAgICAgICBoZWlnaHQ6IDMwMHB4OyAgXHJcbiAgICAgICAgd2lkdGg6IDEwMCUgOyAgXHJcbiAgICB9XHJcbn1cclxuICAgICJdfQ== */"

/***/ }),

/***/ "./src/app/user/trang-chu/video/video.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/video/video.component.ts ***!
  \*********************************************************/
/*! exports provided: VideoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VideoComponent", function() { return VideoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var VideoComponent = /** @class */ (function () {
    function VideoComponent() {
    }
    VideoComponent.prototype.ngOnInit = function () {
    };
    VideoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-video',
            template: __webpack_require__(/*! ./video.component.html */ "./src/app/user/trang-chu/video/video.component.html"),
            styles: [__webpack_require__(/*! ./video.component.scss */ "./src/app/user/trang-chu/video/video.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], VideoComponent);
    return VideoComponent;
}());



/***/ })

}]);
//# sourceMappingURL=trang-chu-trang-chu-module.js.map